var centreentity = {
    country: "country",
    state: "state",
    city: "state"
}

module.exports = centreentity;