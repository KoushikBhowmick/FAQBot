var productentity = {
    country: "country",
    product: "product"
}

module.exports = productentity;