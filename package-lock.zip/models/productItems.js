var productItems = ["IELTS Life Skills", "IELTS for UKVI","IELTS"];
module.exports = productItems;