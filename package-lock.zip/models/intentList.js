var intentList = {
    centre: "CENTER",
    productprice: "PRICE"
}

module.exports = intentList;